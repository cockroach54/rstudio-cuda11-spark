.. important::

    wanna play a game?

    - inside
    - this

      - list
      - ``in the world``

        - hi
        - his

          hi



A list
======

- here
  - is
  - some
    - list
    - items
    - `yahoo <http://www.yahoo.com>`_
    - ``huh``
- how
- ``inline literall``
- ``inline literall``
- ``inline literall``

Second list level
-----------------

- here is a list in a second-level section.
- `yahoo <http://www.yahoo.com>`_
- `yahoo <http://www.yahoo.com>`_

  - `yahoo <http://www.yahoo.com>`_
  - here is an inner bullet ``oh``

    - one more ``with an inline literally``. `yahoo <http://www.yahoo.com>`_
      
      heh heh. child. try to beat this embed:

      .. literalinclude:: test_py_module/test.py
          :language: python
          :linenos:
          :lines: 1-10
  - and another. `yahoo <http://www.yahoo.com>`_
  - `yahoo <http://www.yahoo.com>`_
  - ``hi``
- and hehe

But deeper down the rabbit hole
"""""""""""""""""""""""""""""""

- I kept saying that, "deeper down the rabbit hole". `yahoo <http://www.yahoo.com>`_

  - I cackle at night `yahoo <http://www.yahoo.com>`_.
- I'm so lonely here in GZ ``guangzhou``
- A man of python destiny, hopes and dreams. `yahoo <http://www.yahoo.com>`_

  - `yahoo <http://www.yahoo.com>`_

    - `yahoo <http://www.yahoo.com>`_ ``hi``
    - ``destiny``

