library(testthat)
library(h2o4gpu)

test_check("h2o4gpu")