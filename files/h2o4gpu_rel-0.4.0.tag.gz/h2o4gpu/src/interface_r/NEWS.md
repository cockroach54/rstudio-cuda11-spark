## h2o4gpu 0.2.0.9999 (Development)

* Added support for sparse matrices from `Matrix` R package for Random Forest models.

## h2o4gpu 0.2.0 (CRAN)

* Initial release.
