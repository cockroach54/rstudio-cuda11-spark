# -*- encoding: utf-8 -*-
"""
Test import of h2o4gpu

:copyright: 2017-2018 H2O.ai, Inc.
:license:   Apache License Version 2.0 (see LICENSE for details)
"""


#
def func():
    import h2o4gpu

def test_import(): func()

if __name__ == '__main__':
    test_import()
