.. h2o4gpu documentation master file, created by
   sphinx-quickstart on Thu Aug 31 14:33:52 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

H2O4GPU documentation
===================================

.. toctree::
   intro 
   h2o4gpu.solvers
   h2o4gpu.util

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
