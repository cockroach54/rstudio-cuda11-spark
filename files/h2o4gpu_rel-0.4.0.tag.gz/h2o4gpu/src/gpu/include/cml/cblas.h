#ifndef CBLAS_H_
#define CBLAS_H_

enum CBLAS_SIDE {CblasLeft = 141, CblasRight = 142};
enum CBLAS_ORDER {CblasRowMajor = 101, CblasColMajor = 102};

#endif  // CBLAS_H_

