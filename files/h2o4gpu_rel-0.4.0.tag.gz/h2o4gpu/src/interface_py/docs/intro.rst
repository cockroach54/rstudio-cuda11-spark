:tocdepth: 2


The H2O4GPU Python Module
=========================

H2O4GPU is a collection of GPU (and CPU) solvers by H2Oai, as drop-in replacement of sklearn with GPU capabilities.

In addition, H2O4GPU is an open-source project under the Apache v2 licence. All of the source code is on 
`github <https://github.com/h2oai/h2o4gpu>`_.
